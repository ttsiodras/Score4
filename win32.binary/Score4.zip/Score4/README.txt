Simply run "Score4.exe".

This is a simple implementation of Score4 (also called Connect4).
The goal is to form horizontal, vertical or diagonal series of
4 of your chips (green). The computer tries to do the same, using
red chips.

Keys:

- ESCAPE to exit 
- SPACE to start a new game.

Complete GPL'ed source code at:
http://users.softlab.ntua.gr/~ttsiod/score4.html
